# SpiceVilla — Web Technology Restaurant System

## Technology
- HTML5
- CSS3
- JavaScript (ES6)
- Browser LocalStorage for demo cart data
- Responsive UI

## Modules
- Premium public restaurant website
- Menu search and category filtering
- Customer interface
- Owner dashboard
- POS billing
- Kitchen Display System / KOT
- Table/reservation-ready interface
- GST billing UI with configurable CGST/SGST demo rates

## Run
No server is required for the front-end demo. Open `index.html` in a browser, or use VS Code Live Server for the best experience.

## Demo navigation
Home → Customer / Order Online
Login → Customer interface
Owner Portal → Owner dashboard
Owner Dashboard → POS / Kitchen

## Important
This is the web-technology front-end version. Real multi-user authentication, MySQL persistence, payment gateway, PDF generation and server-side GST/tax validation require a backend/API layer and production credentials.
