const foods=[
{name:'Paneer Tikka',cat:'Starters',price:210,img:'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?auto=format&fit=crop&w=700&q=80',desc:'Tandoor-charred cottage cheese with peppers and onions.'},
{name:'Hara Bhara Kebab',cat:'Starters',price:180,img:'https://images.unsplash.com/photo-1601050690117-94f5f6fa8bd7?auto=format&fit=crop&w=700&q=80',desc:'Spinach, peas and aromatic herbs, crisp outside and tender inside.'},
{name:'Shahi Paneer',cat:'Main Course',price:260,img:'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=700&q=80',desc:'Cottage cheese in a rich, gently spiced royal gravy.'},
{name:'Dal Makhani',cat:'Main Course',price:230,img:'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=700&q=80',desc:'Slow-cooked black lentils finished with butter and cream.'},
{name:'Vegetable Biryani',cat:'Rice & Biryani',price:240,img:'https://images.unsplash.com/photo-1563379091339-03246963d51a?auto=format&fit=crop&w=700&q=80',desc:'Fragrant basmati rice layered with garden vegetables and spices.'},
{name:'Garlic Naan',cat:'Breads',price:75,img:'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=700&q=80',desc:'Tandoor-baked naan brushed with garlic and butter.'},
{name:'Mango Lassi',cat:'Beverages',price:120,img:'https://images.unsplash.com/photo-1579954115545-a95591f28bfc?auto=format&fit=crop&w=700&q=80',desc:'Creamy yoghurt drink blended with ripe Alphonso mango.'},
{name:'Gulab Jamun',cat:'Desserts',price:110,img:'https://images.unsplash.com/photo-1666190094762-9b6d6f3e7a34?auto=format&fit=crop&w=700&q=80',desc:'Soft milk dumplings soaked in warm cardamom syrup.'}];
function foodCard(f){return `<article class="food-card"><img src="${f.img}" alt="${f.name}"><div class="food-body"><span class="veg"></span><div class="food-title"><h3>${f.name}</h3><b class="price">₹${f.price}</b></div><p>${f.desc}</p><button class="btn btn-primary" onclick='addToCart(${JSON.stringify(f)})'>Add to Cart</button></div></article>`}
function renderFeatured(){let el=document.getElementById('featured');if(el)el.innerHTML=foods.slice(0,4).map(foodCard).join('')}
function addToCart(food){let cart=JSON.parse(localStorage.getItem('spiceCart')||'[]');let x=cart.find(i=>i.name===food.name);x?x.qty++:cart.push({...food,qty:1});localStorage.setItem('spiceCart',JSON.stringify(cart));updateCartCount();toast(food.name+' added to cart')}
function updateCartCount(){let n=JSON.parse(localStorage.getItem('spiceCart')||'[]').reduce((s,i)=>s+i.qty,0);document.querySelectorAll('.cart-count').forEach(x=>x.textContent=n)}
function toast(msg){let t=document.createElement('div');t.textContent=msg;t.style='position:fixed;right:22px;bottom:22px;background:#123d32;color:white;padding:13px 18px;border-radius:9px;z-index:100;font-weight:700';document.body.appendChild(t);setTimeout(()=>t.remove(),1800)}
function getFoods(){return foods}
document.addEventListener('DOMContentLoaded',()=>{updateCartCount();document.querySelector('.menu-toggle')?.addEventListener('click',()=>document.querySelector('nav').classList.toggle('show'))})
