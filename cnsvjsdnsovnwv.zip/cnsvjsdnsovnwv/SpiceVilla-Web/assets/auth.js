(() => {
    const SESSION_KEY = 'spiceVillaOwnerSession';
    const CUSTOMER_SESSION_KEY = 'spiceVillaCustomerSession';
    const protectedPages = ['owner.html', 'pos.html', 'kitchen.html'];
    const pageName = window.location.pathname.split('/').pop().toLowerCase();

    function activateCustomerRole() {
        if (pageName === 'customer.html' || pageName === 'login.html') {
            sessionStorage.removeItem(SESSION_KEY);
            if (pageName === 'customer.html') sessionStorage.setItem(CUSTOMER_SESSION_KEY, 'active');
        }
    }

    function requireOwnerSession() {
        if (protectedPages.includes(pageName) && sessionStorage.getItem(SESSION_KEY) !== 'active') {
            window.location.replace(new URL('owner-login.html', window.location.href).href);
        }
    }

    requireOwnerSession();
    activateCustomerRole();
    window.addEventListener('pageshow', requireOwnerSession);
    window.addEventListener('pageshow', activateCustomerRole);

    document.addEventListener('DOMContentLoaded', () => {
        const loginForm = document.getElementById('ownerLoginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', (event) => {
                event.preventDefault();
                if (!loginForm.reportValidity()) return;
                sessionStorage.removeItem(CUSTOMER_SESSION_KEY);
                sessionStorage.setItem(SESSION_KEY, 'active');
                window.location.replace('owner.html');
            });
        }

        const customerLoginForm = document.getElementById('customerLoginForm');
        if (customerLoginForm) {
            customerLoginForm.addEventListener('submit', (event) => {
                event.preventDefault();
                if (!customerLoginForm.reportValidity()) return;
                sessionStorage.removeItem(SESSION_KEY);
                sessionStorage.setItem(CUSTOMER_SESSION_KEY, 'active');
                window.location.replace('customer.html');
            });
        }

        document.querySelectorAll('[data-customer-entry]').forEach((link) => {
            link.addEventListener('click', () => {
                sessionStorage.removeItem(SESSION_KEY);
                sessionStorage.setItem(CUSTOMER_SESSION_KEY, 'active');
            });
        });

        document.querySelectorAll('[data-owner-logout]').forEach((link) => {
            link.addEventListener('click', () => {
                sessionStorage.removeItem(SESSION_KEY);
                sessionStorage.removeItem(CUSTOMER_SESSION_KEY);
            });
        });

        document.querySelectorAll('[data-customer-logout]').forEach((link) => {
            link.addEventListener('click', () => {
                sessionStorage.removeItem(CUSTOMER_SESSION_KEY);
                sessionStorage.removeItem(SESSION_KEY);
            });
        });
    });
})();