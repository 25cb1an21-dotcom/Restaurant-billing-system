(() => {
        const ORDER_KEY = 'spiceVillaOrders';
        const CART_KEY = 'spiceCart';
        const LAST_ORDER_KEY = 'spiceVillaLastOrderId';

        const readList = (key) => {
            try {
                const value = JSON.parse(localStorage.getItem(key) || '[]');
                return Array.isArray(value) ? value : [];
            } catch {
                return [];
            }
        };

        const writeOrders = (orders) => localStorage.setItem(ORDER_KEY, JSON.stringify(orders));
        const money = (amount) => `₹${Number(amount || 0).toLocaleString('en-IN')}`;
        const invoiceMoney = (amount) => `₹${Number(amount || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
        const safe = (value) => String(value == null ? '' : value).replace(/[&<>"']/g, (char) => ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#39;'
        })[char]);

        function getInvoiceLines(order) {
            const savedLines = order.invoice && Array.isArray(order.invoice.taxLines) ? order.invoice.taxLines : [];
            const items = Array.isArray(order.items) ? order.items : [];
            return savedLines.length ? savedLines.map((line, index) => ({
                ...line,
                description: line.description || (items[index] ? items[index].desc : '') || ''
            })) : items.map((item) => ({
                name: item.name,
                description: item.desc || '',
                quantity: Number(item.qty) || 1,
                unitPrice: Number(item.price || 0),
                taxableValue: Number(item.price || 0) * (Number(item.qty) || 1),
                cgst: 0,
                sgst: 0
            }));
        }

        function invoiceDescription(order) {
            return getInvoiceLines(order).map((line) => `${line.name}${line.description ? ` — ${line.description}` : ''}`).join('; ');
        }

        function issueInvoice(order) {
            const taxLines = (Array.isArray(order.items) ? order.items : []).map((item) => {
                const quantity = Number(item.qty) || 1;
                const taxableValue = Number((Number(item.price || 0) * quantity).toFixed(2));
                return {
                    name: item.name,
                    description: item.desc || '',
                    quantity,
                    unitPrice: Number(item.price || 0),
                    taxableValue,
                    cgst: Number((taxableValue * 0.025).toFixed(2)),
                    sgst: Number((taxableValue * 0.025).toFixed(2))
                };
            });
            const subtotal = Number(taxLines.reduce((sum, line) => sum + line.taxableValue, 0).toFixed(2)) || Number(order.total || 0);
            const cgst = Number(taxLines.reduce((sum, line) => sum + line.cgst, 0).toFixed(2)) || Number((subtotal * 0.025).toFixed(2));
            const sgst = Number(taxLines.reduce((sum, line) => sum + line.sgst, 0).toFixed(2)) || Number((subtotal * 0.025).toFixed(2));
            order.invoice = {
                number: `SV-INV-${Date.now().toString(36).toUpperCase()}`,
                issuedAt: new Date().toISOString(),
                seller: 'SpiceVilla',
                sellerAddress: 'Jabalpur, Madhya Pradesh, India',
                placeOfSupply: 'Madhya Pradesh',
                taxLines,
                cgstRate: 2.5,
                sgstRate: 2.5,
                subtotal,
                cgst,
                sgst,
                total: Number((subtotal + cgst + sgst).toFixed(2)),
                paymentStatus: 'Unpaid'
            };
        }

        function renderCart() {
            const list = document.getElementById('cartItems');
            const totalNode = document.getElementById('cartTotal');
            const placeButton = document.getElementById('placeOrderButton');
            if (!list || !totalNode || !placeButton) return;

            const cart = readList(CART_KEY).filter((item) => item && item.qty > 0);
            const total = cart.reduce((sum, item) => sum + Number(item.price || 0) * Number(item.qty || 0), 0);
            list.innerHTML = cart.length ?
                cart.map((item) => `<div class="cart-order-line"><span>${safe(item.name)} × ${Number(item.qty)}</span><b>${money(Number(item.price) * Number(item.qty))}</b></div>`).join('') :
                '<p class="cart-empty">Your cart is empty. Browse the menu to add dishes.</p>';
            totalNode.textContent = money(total);
            placeButton.disabled = cart.length === 0;
        }

        function renderCustomerOrder() {
            const statusNode = document.getElementById('customerOrderStatus');
            if (!statusNode) return;
            const lastOrderId = localStorage.getItem(LAST_ORDER_KEY);
            const order = readList(ORDER_KEY).find((item) => item.id === lastOrderId);
            if (!order) {
                statusNode.hidden = true;
                document.getElementById('customerCurrentOrderNumber').textContent = '#1052';
                document.getElementById('customerCurrentOrderStatus').textContent = 'Preparing';
                document.getElementById('customerCurrentOrderAmount').textContent = '₹620';
                document.getElementById('customerCurrentOrderEta').textContent = '25 min';
                return;
            }

            const statusMessages = {
                New: 'Your order has been sent to the restaurant.',
                Accepted: 'The restaurant accepted your order.',
                Preparing: 'Your order is being prepared.',
                Ready: 'Your order is ready.',
                Completed: 'This order is complete.'
            };
            const itemsNode = document.getElementById('customerOrderItems');
            const items = Array.isArray(order.items) ? order.items : [];
            const eta = order.status === 'Ready' ? 'Ready' : order.status === 'Completed' ? 'Done' : '25 min';

            document.getElementById('customerCurrentOrderNumber').textContent = order.id;
            document.getElementById('customerCurrentOrderStatus').textContent = order.status;
            document.getElementById('customerCurrentOrderAmount').textContent = money(order.invoice ? order.invoice.total : order.total);
            document.getElementById('customerCurrentOrderEta').textContent = eta;
            if (itemsNode) {
                itemsNode.innerHTML = items.length ?
                    items.map((item) => `<tr><td>${safe(item.name)}</td><td>${Number(item.qty) || 1}</td><td>${money(Number(item.price) * (Number(item.qty) || 1))}</td><td><span class="badge">${safe(order.status)}</span></td></tr>`).join('') :
                    '<tr><td colspan="4">No items in this order.</td></tr>';
            }
            statusNode.hidden = false;
            const invoiceText = order.invoice ? ` Invoice ${safe(order.invoice.number)}: ${money(order.invoice.total)} · ${safe(order.invoice.paymentStatus)}.` : '';
            statusNode.innerHTML = `<strong>Order ${safe(order.id)} · ${safe(order.status)}</strong><span>${safe(statusMessages[order.status] || 'Your order status has been updated.')}${invoiceText}</span>`;
        }

        function renderCustomerBills() {
            const list = document.getElementById('customerBillsList');
            const count = document.getElementById('customerBillCount');
            if (!list || !count) return;

            const customerNameInput = document.getElementById('orderCustomer');
            const customerName = customerNameInput ? customerNameInput.value.trim().toLowerCase() : '';
            const bills = readList(ORDER_KEY).filter((order) => order.invoice && customerName && String(order.customer || '').trim().toLowerCase() === customerName);
            count.textContent = `${bills.length} ${bills.length === 1 ? 'bill' : 'bills'}`;
            if (!bills.length) {
                list.innerHTML = '<div class="incoming-empty"><strong>No bills yet</strong><span>Your invoices will appear here after the restaurant issues them.</span></div>';
                return;
            }

            list.innerHTML = bills.map((order) => `<article class="customer-bill-card">
                <div class="customer-bill-heading"><div><strong>${safe(order.invoice.number)}</strong><span>Order ${safe(order.id)} · ${safe(order.type)}</span></div><span class="bill-payment-status ${order.invoice.paymentStatus === 'Paid' ? 'is-paid' : ''}">${safe(order.invoice.paymentStatus)}</span></div>
                <div class="customer-bill-items"><strong>Bill description</strong>${getInvoiceLines(order).map((line) => `<div><b>${safe(line.name)}</b>${line.description ? `<span>${safe(line.description)}</span>` : ''}<small>Qty ${Number(line.quantity) || 1} · ${invoiceMoney(line.taxableValue)}</small></div>`).join('')}</div>
                <div class="customer-bill-tax"><span>Taxable subtotal <b>${invoiceMoney(order.invoice.subtotal)}</b></span><span>CGST <b>${invoiceMoney(order.invoice.cgst)}</b></span><span>SGST <b>${invoiceMoney(order.invoice.sgst)}</b></span></div>
                <div class="customer-bill-total"><span>GST total</span><strong>${money(order.invoice.total)}</strong></div>
                <button class="btn btn-primary" type="button" data-print-invoice="${safe(order.id)}">View / Print bill</button>
            </article>`).join('');
        }

        function placeOrder(event) {
            event.preventDefault();
            const cart = readList(CART_KEY).filter((item) => item && item.qty > 0);
            if (!cart.length) return;

            const orders = readList(ORDER_KEY);
            const total = cart.reduce((sum, item) => sum + Number(item.price || 0) * Number(item.qty || 0), 0);
            const customerInput = document.getElementById('orderCustomer');
            const orderTypeInput = document.getElementById('orderType');
            const paymentInput = document.getElementById('orderPayment');
            const order = {
                id: `SV-${Date.now().toString(36).toUpperCase()}`,
                createdAt: new Date().toISOString(),
                customer: customerInput ? customerInput.value.trim() || 'Guest Customer' : 'Guest Customer',
                type: orderTypeInput ? orderTypeInput.value : 'Takeaway',
                payment: paymentInput ? paymentInput.value : 'Pay at restaurant',
                items: cart,
                total,
                status: 'New'
            };

            try {
                writeOrders([order, ...orders]);
                localStorage.removeItem(CART_KEY);
                localStorage.setItem(LAST_ORDER_KEY, order.id);
                renderCart();
                renderCustomerOrder();
            } catch {
                const statusNode = document.getElementById('customerOrderStatus');
                if (statusNode) {
                    statusNode.hidden = false;
                    statusNode.textContent = 'Could not save the demo order in this browser. Please try again.';
                }
            }
        }

        function nextStatus(status) {
            return ({
                New: ['Accepted', 'Accept order'],
                Accepted: ['Preparing', 'Start preparing'],
                Preparing: ['Ready', 'Mark ready'],
                Ready: ['Completed', 'Complete order']
            })[status] || null;
        }

        function renderOwnerOrders() {
            const list = document.getElementById('incomingOrders');
            const countNode = document.getElementById('incomingOrderCount');
            if (!list || !countNode) return;

            const orders = readList(ORDER_KEY);
            const activeOrders = orders.filter((order) => order.status !== 'Completed');
            const newCount = orders.filter((order) => order.status === 'New').length;
            countNode.textContent = `${newCount} new`;
            countNode.classList.toggle('has-new-orders', newCount > 0);

            if (!activeOrders.length) {
                list.innerHTML = '<div class="incoming-empty"><strong>No incoming orders right now</strong><span>Orders placed from the customer menu will appear here automatically.</span></div>';
                return;
            }

            list.innerHTML = activeOrders.map((order) => {
                        const transition = nextStatus(order.status);
                        const items = Array.isArray(order.items) ? order.items : [];
                        const timestamp = order.createdAt ? new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';
                        return `<article class="incoming-order${order.status === 'New' ? ' is-new' : ''}">
                <div class="incoming-order-head"><div><span class="incoming-order-id">Order ${safe(order.id)}</span><span class="incoming-order-time">${safe(timestamp)}</span></div><span class="incoming-order-status status-${safe(order.status).toLowerCase()}">${safe(order.status)}</span></div>
                <div class="incoming-order-meta"><strong>${safe(order.customer)}</strong><span>${safe(order.type)} · ${safe(order.payment)}</span></div>
                <ul>${items.map((item) => `<li>${safe(item.name)} <span>× ${Number(item.qty) || 1}</span></li>`).join('')}</ul>
                <div class="incoming-order-bill">${order.invoice
                    ? `<span>${safe(order.invoice.number)} · ${safe(order.invoice.paymentStatus)} · ${money(order.invoice.total)}</span><span class="bill-actions"><button class="btn btn-light" type="button" data-print-invoice="${safe(order.id)}">View / Print</button>${order.invoice.paymentStatus === 'Unpaid' ? `<button class="btn btn-light" type="button" data-order-id="${safe(order.id)}" data-billing-action="paid">Mark paid</button>` : ''}</span>`
                    : `<button class="btn btn-light" type="button" data-order-id="${safe(order.id)}" data-billing-action="invoice">Generate GST bill</button>`}</div>
                <div class="incoming-order-foot"><strong>${money(order.total)}</strong>${transition ? `<button class="btn btn-primary" type="button" data-order-id="${safe(order.id)}" data-next-status="${safe(transition[0])}">${safe(transition[1])}</button>` : ''}</div>
            </article>`;
        }).join('');
    }

    function renderOwnerBilling() {
        const list = document.getElementById('ownerBillsList');
        const countNode = document.getElementById('ownerBillCount');
        const unpaidNode = document.getElementById('ownerUnpaidTotal');
        const paidNode = document.getElementById('ownerPaidTotal');
        if (!list || !countNode || !unpaidNode || !paidNode) return;

        const bills = readList(ORDER_KEY).filter((order) => order.invoice);
        const unpaid = bills.filter((order) => order.invoice.paymentStatus !== 'Paid').reduce((sum, order) => sum + order.invoice.total, 0);
        const paid = bills.filter((order) => order.invoice.paymentStatus === 'Paid').reduce((sum, order) => sum + order.invoice.total, 0);
        countNode.textContent = String(bills.length);
        unpaidNode.textContent = money(unpaid);
        paidNode.textContent = money(paid);

        if (!bills.length) {
            list.innerHTML = '<tr><td colspan="9">No invoices yet. Generate a GST bill from an incoming order.</td></tr>';
            return;
        }

        list.innerHTML = bills.map((order) => `<tr>
            <td>${safe(order.invoice.number)}</td><td>${safe(order.id)}</td><td>${safe(order.customer)}</td><td>${safe(invoiceDescription(order))}</td>
            <td>${money(order.invoice.subtotal)}</td><td>${money(order.invoice.cgst + order.invoice.sgst)}</td>
            <td><strong>${money(order.invoice.total)}</strong></td>
            <td><span class="bill-payment-status ${order.invoice.paymentStatus === 'Paid' ? 'is-paid' : ''}">${safe(order.invoice.paymentStatus)}</span></td>
            <td><span class="bill-actions"><button class="btn btn-light" type="button" data-print-invoice="${safe(order.id)}">Print</button>${order.invoice.paymentStatus === 'Unpaid' ? `<button class="btn btn-primary" type="button" data-order-id="${safe(order.id)}" data-billing-action="paid">Mark paid</button>` : ''}</span></td>
        </tr>`).join('');
    }

    function updateOrder(event) {
        const button = event.target.closest('[data-order-id][data-next-status]');
        if (!button) return;
        const orders = readList(ORDER_KEY);
        const order = orders.find((item) => item.id === button.dataset.orderId);
        if (!order) return;
        order.status = button.dataset.nextStatus;
        writeOrders(orders);
        renderOwnerOrders();
    }

    function updateBilling(event) {
        const button = event.target.closest('[data-order-id][data-billing-action]');
        if (!button) return;
        const orders = readList(ORDER_KEY);
        const order = orders.find((item) => item.id === button.dataset.orderId);
        if (!order) return;
        if (button.dataset.billingAction === 'invoice' && !order.invoice) issueInvoice(order);
        if (button.dataset.billingAction === 'paid' && order.invoice) {
            order.invoice.paymentStatus = 'Paid';
            order.invoice.paidAt = new Date().toISOString();
        }
        writeOrders(orders);
        renderOwnerOrders();
        renderOwnerBilling();
    }

    function printCustomerInvoice(event) {
        const button = event.target.closest('[data-print-invoice]');
        if (!button) return;
        const order = readList(ORDER_KEY).find((item) => item.id === button.dataset.printInvoice && item.invoice);
        if (!order) return;

        const invoice = order.invoice;
        const taxLines = getInvoiceLines(order);
        const rows = taxLines.map((line) => `<tr><td><strong>${safe(line.name)}</strong>${line.description ? `<small class="item-description">${safe(line.description)}</small>` : ''}</td><td>${Number(line.quantity) || 1}</td><td>${invoiceMoney(line.unitPrice)}</td><td>${invoiceMoney(line.taxableValue)}</td><td>${invoiceMoney(line.cgst)}</td><td>${invoiceMoney(line.sgst)}</td><td>${invoiceMoney(line.taxableValue + line.cgst + line.sgst)}</td></tr>`).join('');
        const printWindow = window.open('', '_blank', 'width=760,height=820');
        if (!printWindow) {
            window.alert('Allow pop-ups to view or print your bill.');
            return;
        }
        printWindow.document.write(`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${safe(invoice.number)} | GST Tax Invoice</title><style>
            *{box-sizing:border-box}body{font:14px/1.5 Arial,sans-serif;color:#25382f;max-width:900px;margin:30px auto;padding:30px;background:#fff}header{display:flex;justify-content:space-between;gap:24px;border-bottom:3px solid #123d32;padding-bottom:20px}.brand{font-size:28px;font-weight:800;color:#123d32}.muted{color:#65756b}.invoice-tag{display:inline-block;padding:6px 10px;border-radius:4px;background:#e8f1e9;color:#123d32;font-weight:bold}h1{margin:24px 0 4px;color:#123d32;font-size:26px}.meta{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin:20px 0}.box{padding:14px;border:1px solid #dfe7e0;border-radius:6px}.box strong{display:block;margin-bottom:4px;color:#123d32}table{width:100%;border-collapse:collapse;margin:24px 0;font-size:12px}th{background:#123d32;color:#fff}th,td{text-align:right;padding:10px 8px;border:1px solid #dfe4dd}th:first-child,td:first-child{text-align:left}.item-description{display:block;margin-top:3px;color:#65756b;font-size:10px;font-weight:normal}.totals{width:min(380px,100%);margin-left:auto}.row{display:flex;justify-content:space-between;gap:20px;padding:7px 0;border-bottom:1px solid #edf0ec}.grand{margin-top:6px;padding:13px 0;border-top:2px solid #123d32;border-bottom:0;color:#123d32;font-size:19px;font-weight:bold}.footnote{margin-top:24px;padding:12px;background:#f7f8f5;color:#637168;font-size:11px}@media(max-width:620px){body{margin:0;padding:14px}.meta{grid-template-columns:1fr}table{font-size:10px}th,td{padding:6px 4px}}@media print{body{max-width:none;margin:0;padding:12mm}.no-print{display:none}}
            </style></head><body>
            <header><div><div class="brand">${safe(invoice.seller || 'SpiceVilla')}</div><div>${safe(invoice.sellerAddress || 'Jabalpur, Madhya Pradesh, India')}</div><div class="muted">GSTIN: Not configured (demo)</div></div><div style="text-align:right"><span class="invoice-tag">GST INVOICE · DEMO</span><p><strong>Invoice No.</strong> ${safe(invoice.number)}<br><strong>Date</strong> ${new Date(invoice.issuedAt).toLocaleDateString('en-IN')}<br><strong>Order</strong> ${safe(order.id)}</p></div></header>
            <h1>Tax Invoice</h1><p class="muted">Original for recipient · Currency: INR</p>
            <div class="meta"><div class="box"><strong>Bill to</strong>${safe(order.customer)}<br>Customer details not provided</div><div class="box"><strong>Supply details</strong>Order type: ${safe(order.type)}<br>Place of supply: ${safe(invoice.placeOfSupply || 'Madhya Pradesh')}<br>Payment: ${safe(order.payment)}</div></div>
            <table><thead><tr><th>Item description</th><th>Qty</th><th>Unit price</th><th>Taxable value</th><th>CGST 2.5%</th><th>SGST 2.5%</th><th>Line total</th></tr></thead><tbody>${rows}</tbody></table>
            <div class="totals"><div class="row"><span>Taxable subtotal</span><strong>${invoiceMoney(invoice.subtotal)}</strong></div><div class="row"><span>CGST @ ${Number(invoice.cgstRate) || 2.5}%</span><strong>${invoiceMoney(invoice.cgst)}</strong></div><div class="row"><span>SGST @ ${Number(invoice.sgstRate) || 2.5}%</span><strong>${invoiceMoney(invoice.sgst)}</strong></div><div class="row grand"><span>Invoice total</span><strong>${invoiceMoney(invoice.total)}</strong></div><div class="row"><span>Payment status</span><strong>${safe(invoice.paymentStatus)}</strong></div></div>
            <div class="footnote">Demo invoice: the GSTIN is not configured and tax values/rates are sample values only. Confirm registration, tax classification, rates, customer details, and applicable GST rules before issuing a production tax invoice. No payment is processed by this demo.</div>
            <script>window.onload=()=>window.print()</script></body></html>`);
        printWindow.document.close();
    }

    const placeOrderForm = document.getElementById('placeOrderForm');
    if (placeOrderForm) placeOrderForm.addEventListener('submit', placeOrder);

    const incomingOrders = document.getElementById('incomingOrders');
    if (incomingOrders) {
        incomingOrders.addEventListener('click', updateOrder);
        incomingOrders.addEventListener('click', updateBilling);
    }
    const ownerBillsList = document.getElementById('ownerBillsList');
    if (ownerBillsList) {
        ownerBillsList.addEventListener('click', updateBilling);
        ownerBillsList.addEventListener('click', printCustomerInvoice);
    }
    if (incomingOrders) incomingOrders.addEventListener('click', printCustomerInvoice);
    const customerBillsList = document.getElementById('customerBillsList');
    if (customerBillsList) customerBillsList.addEventListener('click', printCustomerInvoice);
    const orderCustomerInput = document.getElementById('orderCustomer');
    if (orderCustomerInput) orderCustomerInput.addEventListener('input', renderCustomerBills);
    window.addEventListener('storage', (event) => {
        if (!event.key || [ORDER_KEY, CART_KEY, LAST_ORDER_KEY].includes(event.key)) {
            renderCart();
            renderCustomerOrder();
            renderCustomerBills();
            renderOwnerOrders();
            renderOwnerBilling();
        }
    });

    renderCart();
    renderCustomerOrder();
    renderCustomerBills();
    renderOwnerOrders();
    renderOwnerBilling();
})();